// import Pepperoni from "../assets/pepperoni.jpg";
// import Margherita from "../assets/margherita.jpg";
// import PedroTechSpecial from "../assets/pedrotechspecial.jpg";
// import Vegan from "../assets/vegan.jpg";
// import Pineapple from "../assets/pineapple.jpg";
// import Expensive from "../assets/expensive.jpg";

export const MenuList = [
  {
    postID: 1,
    title: "Hoa viếng - G260",
    description: "A beautiful condolence flower arrangement with white lilies.",
    price: 600.00,
    imageUrl: "public/flowerimgs/flower1.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 2,
    title: "Hoa viếng - V159",
    description: "A stunning standing flower arrangement with mixed flowers.",
    price: 790.00,
    imageUrl: "https://example.com/v159.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },
  {
    postID: 3,
    title: "Hoa viếng - C100",
    description: "A circular wreath with white flowers for condolences.",
    price: 850.00,
    imageUrl: "https://example.com/c100.jpg",
    status: "Available",
    rating: 5,
  },

  // Add more flower posts here
];

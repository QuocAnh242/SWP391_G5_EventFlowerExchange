package com.SWP391_G5_EventFlowerExchange.LoginAPI.entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackKey implements Serializable {
    private int userID;
    private int sellerID;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeedbackKey that = (FeedbackKey) o;
        return userID == that.userID && sellerID == that.sellerID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(userID, sellerID);
    }

}


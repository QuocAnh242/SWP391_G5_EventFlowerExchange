package com.SWP391_G5_EventFlowerExchange.LoginAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}

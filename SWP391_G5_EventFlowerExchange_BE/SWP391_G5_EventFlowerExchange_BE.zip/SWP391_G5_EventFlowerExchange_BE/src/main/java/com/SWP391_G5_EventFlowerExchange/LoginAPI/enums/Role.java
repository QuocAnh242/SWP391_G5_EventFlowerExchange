package com.SWP391_G5_EventFlowerExchange.LoginAPI.enums;

public enum Role {
    ADMIN,
    BUYER,
    SELLER
}


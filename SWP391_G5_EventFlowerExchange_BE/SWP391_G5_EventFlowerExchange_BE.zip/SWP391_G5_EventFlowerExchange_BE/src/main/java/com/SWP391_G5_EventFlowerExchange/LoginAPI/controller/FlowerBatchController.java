package com.SWP391_G5_EventFlowerExchange.LoginAPI.controller;

import com.SWP391_G5_EventFlowerExchange.LoginAPI.dto.response.ApiResponse;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.entity.FlowerBatch;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.service.FlowerBatchSerivice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/flower")
public class FlowerBatchController {

    @Autowired
    private FlowerBatchSerivice flowerBatchSerivice;

    // Lấy tất cả các FlowerBatch
    @GetMapping("/")
    public ApiResponse<List<FlowerBatch>> fetchAll() {
        List<FlowerBatch> flowerBatches = flowerBatchSerivice.getAllFlowerBatch();
        return new ApiResponse<>(1000, "Flower batches retrieved successfully", flowerBatches);
    }

    // Thêm mới FlowerBatch
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<FlowerBatch> saveFlower(@RequestBody FlowerBatch orchid) {
        FlowerBatch savedFlowerBatch = flowerBatchSerivice.insertFlowerBatch(orchid);
        return new ApiResponse<>(1000, "Flower batch created successfully", savedFlowerBatch);
    }

    // Cập nhật FlowerBatch theo ID
    @PutMapping("/{id}")
    public ApiResponse<FlowerBatch> updateFlowerId(@PathVariable int id, @RequestBody FlowerBatch fb) {
        FlowerBatch updatedFlowerBatch = flowerBatchSerivice.updateFlowerBatch(id, fb);
        return new ApiResponse<>(1000, "Flower batch updated successfully", updatedFlowerBatch);
    }

    // Xóa FlowerBatch theo ID
    @DeleteMapping("/{id}")
    public ApiResponse<String> deleteFlower(@PathVariable int id) {
        flowerBatchSerivice.deleteFlowerBatch(id);
        return new ApiResponse<>(1000, "Flower batch deleted successfully", "Deleted!");
    }

    // Lấy FlowerBatch theo ID
    @GetMapping("/{id}")
    public ApiResponse<Optional<FlowerBatch>> getFbyId(@PathVariable int id) {
        Optional<FlowerBatch> flowerBatch = flowerBatchSerivice.getFlowerBatchById(id);
        return new ApiResponse<>(1000, "Flower batch retrieved successfully", flowerBatch);
    }
}

package com.SWP391_G5_EventFlowerExchange.LoginAPI.service;

import org.springframework.stereotype.Service;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

@Service
public class MoMoPaymentService {

    // MoMo API credentials
    private final String partnerCode = "YOUR_PARTNER_CODE";
    private final String accessKey = "YOUR_ACCESS_KEY";
    private final String secretKey = "YOUR_SECRET_KEY";
    private final String endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";

    public String createPayment(String orderId, String requestId, long amount, String orderInfo, String returnUrl, String notifyUrl) throws Exception {

        // Create MoMo payment parameters
        String requestType = "captureWallet";
        String extraData = ""; // Leave it empty if not used
        String rawData = "accessKey=" + accessKey + "&amount=" + amount + "&extraData=" + extraData
                + "&orderId=" + orderId + "&orderInfo=" + orderInfo
                + "&partnerCode=" + partnerCode + "&redirectUrl=" + returnUrl
                + "&requestId=" + requestId + "&requestType=" + requestType;

        // Generate signature for the request
        String signature = signHmacSHA256(rawData, secretKey);

        // Prepare request body
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("partnerCode", partnerCode);
        requestBody.put("accessKey", accessKey);
        requestBody.put("requestId", requestId);
        requestBody.put("amount", amount);
        requestBody.put("orderId", orderId);
        requestBody.put("orderInfo", orderInfo);
        requestBody.put("returnUrl", returnUrl);
        requestBody.put("notifyUrl", notifyUrl);
        requestBody.put("requestType", requestType);
        requestBody.put("extraData", extraData);
        requestBody.put("signature", signature);

        // Make HTTP request to MoMo API
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        ResponseEntity<String> response = restTemplate.exchange(endpoint, HttpMethod.POST, entity, String.class);

        return response.getBody();
    }

    // HMAC SHA256 signature generator
    private String signHmacSHA256(String data, String key) throws Exception {
        Mac sha256HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(), "HmacSHA256");
        sha256HMAC.init(secretKeySpec);
        return Base64.getEncoder().encodeToString(sha256HMAC.doFinal(data.getBytes()));
    }
}


package com.SWP391_G5_EventFlowerExchange.LoginAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class MainControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainControllerApplication.class, args);
	}

}

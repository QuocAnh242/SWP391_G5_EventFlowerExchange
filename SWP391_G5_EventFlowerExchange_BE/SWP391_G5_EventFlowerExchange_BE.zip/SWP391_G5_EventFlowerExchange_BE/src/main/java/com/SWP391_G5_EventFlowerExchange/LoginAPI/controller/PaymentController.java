package com.SWP391_G5_EventFlowerExchange.LoginAPI.controller;


import com.SWP391_G5_EventFlowerExchange.LoginAPI.service.MoMoPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;
import java.util.UUID;

@Controller
public class PaymentController {

    @Autowired
    private MoMoPaymentService paymentService;

    @GetMapping("/create-payment")
    public String createPayment(Model model, @RequestParam long amount) {
        String orderId = UUID.randomUUID().toString();
        String requestId = UUID.randomUUID().toString();
        String orderInfo = "Payment for order #" + orderId;
        String returnUrl = "http://localhost:8080/payment-result";
        String notifyUrl = "http://localhost:8080/payment-notify";

        try {
            String response = paymentService.createPayment(orderId, requestId, amount, orderInfo, returnUrl, notifyUrl);
            model.addAttribute("paymentUrl", response);
            return "redirect:" + response;  // Redirect user to MoMo payment page
        } catch (Exception e) {
            model.addAttribute("error", "Error processing payment: " + e.getMessage());
            return "error";
        }
    }

    @GetMapping("/payment-result")
    public String paymentResult(@RequestParam Map<String, String> responseParams, Model model) {
        // Handle response from MoMo (successful or failed payment)
        model.addAttribute("response", responseParams);
        return "paymentResult";  // Render result page
    }

    @GetMapping("/payment-notify")
    public String paymentNotify(@RequestParam Map<String, String> responseParams) {
        // Handle MoMo payment notification (use this for server-side order status update)
        // Process the payment result here
        return "notify";
    }
}

package com.SWP391_G5_EventFlowerExchange.LoginAPI.controller;

import com.SWP391_G5_EventFlowerExchange.LoginAPI.dto.response.ApiResponse;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.entity.Payment;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
@CrossOrigin("http://localhost:3000")
public class PaymentController {

    @Autowired
    private IPaymentService paymentService;

    // Tạo mới Payment
    @PostMapping("/")
    public ApiResponse<Payment> createPayment(@RequestBody Payment payment) {
        Payment createdPayment = paymentService.createPayment(payment);
        return new ApiResponse<>(1000, "Payment created successfully", createdPayment);
    }

    // Lấy tất cả Payments
    @GetMapping("/")
    public ApiResponse<List<Payment>> getAllPayments() {
        List<Payment> payments = paymentService.getAllPayments();
        return new ApiResponse<>(1000, "Payments retrieved successfully", payments);
    }

    // Lấy Payment theo ID
    @GetMapping("/{paymentID}")
    public ApiResponse<Payment> getPayment(@PathVariable int paymentID) {
        Payment payment = paymentService.getPayment(paymentID);
        return new ApiResponse<>(1000, "Payment retrieved successfully", payment);
    }

    // Cập nhật Payment
    @PutMapping("/{paymentID}")
    public ApiResponse<Payment> updatePayment(@PathVariable int paymentID, @RequestBody Payment payment) {
        Payment updatedPayment = paymentService.updatePayment(paymentID, payment);
        return new ApiResponse<>(1000, "Payment updated successfully", updatedPayment);
    }

    // Xóa Payment
    @DeleteMapping("/{paymentID}")
    public ApiResponse<String> deletePayment(@PathVariable int paymentID) {
        paymentService.deletePayment(paymentID);
        return new ApiResponse<>(1000, "Payment deleted successfully", "Deleted!");
    }
}

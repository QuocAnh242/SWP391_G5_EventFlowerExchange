package com.SWP391_G5_EventFlowerExchange.LoginAPI.controller;

import com.SWP391_G5_EventFlowerExchange.LoginAPI.entity.Feedback;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.entity.User;
import com.SWP391_G5_EventFlowerExchange.LoginAPI.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feedback")
@CrossOrigin("http://localhost:3000")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @PostMapping("/")
    public ResponseEntity<Feedback> createFeedback(@RequestBody Feedback feedback) {
        return ResponseEntity.ok(feedbackService.saveFeedback(feedback));
    }

    @GetMapping("/seller/{sellerID}")
    public ResponseEntity<List<Feedback>> getFeedbackForSeller(@PathVariable int sellerID) {
        User seller = new User();  // Fetch seller using User service or repository
        seller.setUserID(sellerID);
        return ResponseEntity.ok(feedbackService.getFeedbackForSeller(seller));
    }

    @GetMapping("/user/{userID}")
    public ResponseEntity<List<Feedback>> getFeedbackForUser(@PathVariable int userID) {
        User user = new User();  // Fetch user using User service or repository
        user.setUserID(userID);
        return ResponseEntity.ok(feedbackService.getFeedbackForUser(user));
    }
}


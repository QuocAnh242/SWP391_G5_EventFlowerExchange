package com.SWP391_G5_EventFlowerExchange.LoginAPI.repository;

import com.SWP391_G5_EventFlowerExchange.LoginAPI.entity.FlowerBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IFlowerBatchRepository extends JpaRepository<FlowerBatch, Integer> {

}
